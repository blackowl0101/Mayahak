package com.mayahak.water;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    SharedPreferences prefs; TextView totalText, cupsText, statusText; int total, cups;
    int blue = Color.rgb(22,138,173);
    public void onCreate(Bundle b){ super.onCreate(b); prefs=getSharedPreferences("water",0); createChannel(); askNotifications(); resetIfNewDay(); buildUi(); scheduleReminder(); }
    void resetIfNewDay(){String today=new SimpleDateFormat("yyyyMMdd",Locale.US).format(new Date()); if(!today.equals(prefs.getString("day",""))){prefs.edit().putString("day",today).putInt("total",0).putInt("cups",0).apply();} total=prefs.getInt("total",0); cups=prefs.getInt("cups",0);}
    TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER);t.setPadding(8,12,8,12);return t;}
    Button button(String s){Button b=new Button(this);b.setText(s);b.setTextSize(16);return b;}
    void buildUi(){
      LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setGravity(Gravity.CENTER_HORIZONTAL);root.setPadding(24,30,24,24);root.setBackgroundColor(Color.rgb(240,249,252));
      TextView title=text("ميّاهك",32,Color.rgb(11,57,84));title.setTypeface(null,1);root.addView(title);
      root.addView(text("متابعة شرب المياه",17,Color.DKGRAY));
      totalText=text("إجمالي اليوم: "+total+" مل",24,blue);root.addView(totalText);
      cupsText=text("عدد الأكواب: "+cups,18,Color.DKGRAY);root.addView(cupsText);
      root.addView(text("سعة الكوب: 400 مل",16,Color.DKGRAY));
      Button add=button("+ شربت كوب مياه (400 مل)");add.setOnClickListener(v->{total+=400;cups++;save();refresh();});root.addView(add);
      Button custom=button("إضافة كمية أخرى");custom.setOnClickListener(v->{String[] opts={"100 مل","200 مل","250 مل","300 مل","500 مل"};new AlertDialog.Builder(this).setTitle("اختر الكمية").setItems(opts,(d,w)->{int[] vals={100,200,250,300,500};total+=vals[w];cups++;save();refresh();}).show();});root.addView(custom);
      Button undo=button("تراجع عن آخر كوب");undo.setOnClickListener(v->{if(cups>0){total=Math.max(0,total-400);cups--;save();refresh();}else Toast.makeText(this,"لا توجد أكواب مسجلة",Toast.LENGTH_SHORT).show();});root.addView(undo);
      Button reminder=button("تفعيل / إعادة ضبط تذكير كل ساعة");reminder.setOnClickListener(v->{scheduleReminder();Toast.makeText(this,"تم ضبط التذكير كل ساعة",Toast.LENGTH_LONG).show();});root.addView(reminder);
      Button target=button("تغيير الهدف اليومي");target.setOnClickListener(v->{String[] goals={"1500 مل","2000 مل","2500 مل","3000 مل"};new AlertDialog.Builder(this).setTitle("هدف يومي اختياري").setItems(goals,(d,w)->{prefs.edit().putInt("goal",new int[]{1500,2000,2500,3000}[w]).apply();refresh();}).show();});root.addView(target);
      statusText=text("الهدف: "+prefs.getInt("goal",2000)+" مل\nالتذكير كل ساعة",15,Color.DKGRAY);root.addView(statusText);
      setContentView(root); refresh();
    }
    void save(){prefs.edit().putInt("total",total).putInt("cups",cups).apply();}
    void refresh(){if(totalText!=null){totalText.setText("إجمالي اليوم: "+total+" مل");cupsText.setText("عدد الأكواب: "+cups);statusText.setText("الهدف: "+prefs.getInt("goal",2000)+" مل\n"+(total>=prefs.getInt("goal",2000)?"وصلت لهدفك اليومي":"متبقي "+(prefs.getInt("goal",2000)-total)+" مل")+"\nالتذكير كل ساعة");}}
    void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel("water_hourly","تذكير شرب المياه",NotificationManager.IMPORTANCE_DEFAULT);c.setDescription("تذكير كل ساعة بشرب المياه");((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);}}
    void askNotifications(){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},9);}
    void scheduleReminder(){AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);Intent i=new Intent(this,ReminderReceiver.class);PendingIntent pi=PendingIntent.getBroadcast(this,44,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);long first=System.currentTimeMillis()+60*60*1000L;if(Build.VERSION.SDK_INT>=31&&!am.canScheduleExactAlarms()){try{startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM));}catch(Exception e){} am.setInexactRepeating(AlarmManager.RTC_WAKEUP,first,60*60*1000L,pi);}else if(Build.VERSION.SDK_INT>=23){am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,first,pi);}else{am.setRepeating(AlarmManager.RTC_WAKEUP,first,60*60*1000L,pi);}}
}
